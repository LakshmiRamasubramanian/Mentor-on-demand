import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit {
  user:User =new User();
  MainCtrl($scope) {
    $scope.first = "Angular";
    $scope.second = "JS";
    $scope.truefalse = true;
}
  
  constructor(private userService: UserService) { }

  ngOnInit() {
  }
createUsers(){
    console.log(this.user);
    this.userService.createUsers(this.user)
    .subscribe(data => console.log(data), error => console.log(error));
     this.user=new User();
  }
  onSubmit() {
  
    this.createUsers();
  }
}
