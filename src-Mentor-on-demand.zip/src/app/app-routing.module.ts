import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { MentorRegistrationComponent } from './mentor-registration/mentor-registration.component';
import { AdminRegistrationComponent } from './admin-registration/admin-registration.component';
import { AdminComponent } from './admin/admin.component';
import { AddSkillComponent } from './add-skill/add-skill.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentFormComponent } from './payment-form/payment-form.component';
import { PaymentDetailsComponent } from './payment-details/payment-details.component';
import { UpdateComponent } from './update/update.component';
import { UserComponent } from './user/user.component';
import { FindCourseComponent } from './find-course/find-course.component';
import { MentorComponent } from './mentor/mentor.component';
import { MentorNotificationComponent } from './mentor-notification/mentor-notification.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: 'UserRegistration', component: UserRegistrationComponent },
  { path: 'MentorRegistration', component: MentorRegistrationComponent },
  { path: 'AdminRegistration', component: AdminRegistrationComponent },
  
  { path: 'Admin', component: AdminComponent,
  children:[
    { path:'', component: AddSkillComponent },
    { path:'AddSkill', component: AddSkillComponent },
    { path:'PaymentForm/:id', component: PaymentFormComponent },
    { path:'paymentHistory', component: PaymentDetailsComponent },
    { path:'update/:pay', component: UpdateComponent},
    { path:'payment', component: PaymentComponent}
  ]
},
{ path: 'User', component: UserComponent,
children:[
  { path:'FindCourse', component: FindCourseComponent },
 
]
},
{ path:'Mentor', component: MentorComponent ,
children:[
  { path:' ', component:MentorNotificationComponent },
  { path:'paymentHistory', component: PaymentDetailsComponent },
  { path:'Notifications', component:MentorNotificationComponent }
 
]
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
   
 }
