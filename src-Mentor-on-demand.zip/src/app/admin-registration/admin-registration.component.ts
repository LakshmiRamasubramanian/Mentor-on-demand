import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';
@Component({
  selector: 'app-admin-registration',
  templateUrl: './admin-registration.component.html',
  styleUrls: ['./admin-registration.component.css']
})
export class AdminRegistrationComponent implements OnInit {
  admin:Admin =new Admin();
  constructor(private adminService: AdminService) { }

  ngOnInit() {
  }
  createAdmin(){
    console.log(this.admin);
    this.adminService.createAdmin(this.admin)
    .subscribe(data => console.log(data), error => console.log(error));
     this.admin=new Admin();
  }
  onSubmit() {
  
    this.createAdmin();
  }
}
