import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Router } from '@angular/router';
import {  Payments } from '../PaymentForm';

@Component({
  selector: 'app-payment-details',
  templateUrl: './payment-details.component.html',
  styleUrls: ['./payment-details.component.css']
})
export class PaymentDetailsComponent implements OnInit {
private  payment:Payments[];
  constructor(private adminService: AdminService, private router: Router) { }

  ngOnInit() {
    this.adminService.getPaymentDetails()  
    .subscribe((data: Payments[]) => { 
      console.log(data); 
      this.payment = data;  
    }); 
  }
  updateSlot(pay:number) {  
    
    this.router.navigate(['/Admin/update',pay]);
  }  
}  


