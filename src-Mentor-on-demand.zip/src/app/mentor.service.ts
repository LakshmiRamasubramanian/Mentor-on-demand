import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MentorService {
  public baseUrl = 'http://localhost:8216/api';
  constructor(private http: HttpClient) { }

 

  createMentor(mentor: Object): Observable<Object> {
    console.log(mentor);
    return this.http.post(`${this.baseUrl}`+'/mentor/register',mentor);
  }

}
