import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MentorSkills } from './MentorSkills';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  public baseUrl = 'http://localhost:8216/api';
  constructor(private http: HttpClient) { }

 

  createUsers(user: Object): Observable<Object> {
    console.log(user);
    return this.http.post(`${this.baseUrl}`+'/user/register',user);
  }
  MentorSkills(): Observable<Object> {
    return this.http.get<MentorSkills>(`${this.baseUrl}`+'/mentorSkills');
  }
  
}
