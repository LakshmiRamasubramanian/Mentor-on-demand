export class MentorSkills{
    mentorId:number;
    skillId:number;
    yearsOfExperience:number;
    regDateTime:string;
    trainingsDelivered:string;
    facilities:string;
    
}