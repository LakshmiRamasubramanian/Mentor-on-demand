import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs';
import { Login } from '../login';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  private user: Login[];
  login:Login=new Login();
  email:string;
 
  constructor(private loginService: LoginService) { }

  ngOnInit() {
    this.loginService._email$.subscribe(message=>this.email=message);
  }
  
    
    
}


