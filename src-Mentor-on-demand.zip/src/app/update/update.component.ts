import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { Payments } from '../PaymentForm';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  selectedId:number
  payment:Payments[];
  payments:Payments=new Payments();
  activatedRoute: any;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adminService: AdminService
  ) {}
      
  ngOnInit() {
    this.route.params.subscribe( params => 
      this.selectedId=+params.pay );
    this.getPaymentSlotWithId(this.selectedId);
  }
getPaymentSlotWithId(selectedId:number){
  this.adminService.getPaymentSlotWithId(this.selectedId)
  .subscribe((res : any)=>{
    console.log(res);
    this.payments=res;
    })
}
updateSlotPayment(payments:Payments){
  this.adminService.updateSlotPayment(this.payments)
  .subscribe(data => console.log(data), error => console.log(error));
}
onSubmit(){
 
  this.updateSlotPayment(this.payments)
}

}
