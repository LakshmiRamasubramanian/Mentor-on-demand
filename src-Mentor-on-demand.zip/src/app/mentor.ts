export class Mentor{
    mentorid: number;
    firstName:string;
    LastName:string;
    email: string;
    password: string;
    contactNumber:string;
    linkedinUrl:string;
    regDateTime:String;
    skills:string;
    currentCourse:string;
    yearOfExperience:string;
    status:string;
    role:string;
}
