import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private _email=new BehaviorSubject<string>(this._email);
  _email$=this._email.asObservable();
  setEmail(email: string) {
    console.log("************"+email);
    this._email.next(email);
  }
  public baseUrl = 'http://localhost:8216/api';
  constructor(private http: HttpClient) { }

 

  getLoginCredentials(login: Object): Observable<Object> {
    
    
    return this.http.post(`${this.baseUrl}`+'/getRole/login',login);
  }
  getAdminLogin(): Observable<any> {
    
    return this.http.get(`${this.baseUrl}`+'/getAdminLogin');
   
  }
  

  }

