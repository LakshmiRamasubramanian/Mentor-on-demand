import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Router } from '@angular/router';
import { PaymentHistory } from '../PaymentHistory';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  paymentHistory: PaymentHistory[];  
  constructor(private adminService: AdminService, private router: Router) { }

  ngOnInit() {
    this.adminService.getPayment()  
    .subscribe((data: PaymentHistory[]) => { 
      console.log(data); 
      this.paymentHistory = data;  
    }); 
    
     
  }
  

}
