export class Admin {
    adminId: number;
    email: string;
    name:string
    password: string;
    contact:string;
    status:string
    role:string;
}
