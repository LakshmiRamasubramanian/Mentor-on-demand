import { Component, OnInit } from '@angular/core';
import { Mentor } from '../mentor';
import { MentorService } from '../mentor.service';

@Component({
  selector: 'app-mentor-registration',
  templateUrl: './mentor-registration.component.html',
  styleUrls: ['./mentor-registration.component.css']
})
export class MentorRegistrationComponent implements OnInit {
mentor:Mentor= new Mentor();
  constructor(private mentorService: MentorService) { }

  ngOnInit() {
  }
  createMentor(){
    console.log(this.mentor);
    this.mentorService.createMentor(this.mentor)
    .subscribe(data => console.log(data), error => console.log(error));
     this.mentor=new Mentor();
  }
  onSubmit() {
  
    this.createMentor();
  }
}
