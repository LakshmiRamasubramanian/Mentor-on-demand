import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import { AdminService } from '../admin.service';
import { switchMap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { PaymentHistory } from '../PaymentHistory';
import {  Payments } from '../PaymentForm';

@Component({
  selector: 'app-payment-form',
  templateUrl: './payment-form.component.html',
  styleUrls: ['./payment-form.component.css']
})
export class PaymentFormComponent implements OnInit {
 
 private paymentForm : PaymentHistory[];
 payment:Payments=new Payments();
 skillId:number;
 mentorPaymentId:number;
 selectedId:number
 
  activatedRoute: any;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adminService: AdminService
  ) {}
      
  ngOnInit() {
    this.route.params.subscribe( params => 
      this.selectedId=+params.id );
    this.getPaymentId(this.selectedId);
  }

  getPaymentId(selectedId){
    
    this.adminService.getPaymentHistoryId(this.selectedId)
    .subscribe((res : any[])=>{
      console.log(res);
      this.paymentForm= res;
      this.payment.skillId=res[0].skillId;
      this.payment.mentorPaymentId=res[0].paymentId;
      })
  
     
       
  }
  onSubmit() {  
    console.log(this.payment)
    console.log(this.payment.mentorPaymentId)
    this.adminService.savePaymentToMentor(this.payment). subscribe(data => console.log(data), error => console.log(error));
  }  

}
