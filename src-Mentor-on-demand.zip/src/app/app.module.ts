import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { UserRegistrationComponent } from './user-registration/user-registration.component';

import { MentorRegistrationComponent } from './mentor-registration/mentor-registration.component';
import { AdminRegistrationComponent } from './admin-registration/admin-registration.component';
import { AdminComponent } from './admin/admin.component';
import { AddSkillComponent } from './add-skill/add-skill.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentFormComponent } from './payment-form/payment-form.component';
import { PaymentDetailsComponent } from './payment-details/payment-details.component';
import { UpdateComponent } from './update/update.component';
import { MentorComponent } from './mentor/mentor.component';
import { UserComponent } from './user/user.component';
import { FindCourseComponent } from './find-course/find-course.component';
import { MentorNotificationComponent } from './mentor-notification/mentor-notification.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserRegistrationComponent,
   
    MentorRegistrationComponent,
   
    AdminRegistrationComponent,
   
    AdminComponent,
   
    AddSkillComponent,
   
    PaymentComponent,
   
    PaymentFormComponent,
   
    PaymentDetailsComponent,
   
    UpdateComponent,
   
    MentorComponent,
   
    UserComponent,
   
    FindCourseComponent,
   
    MentorNotificationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
