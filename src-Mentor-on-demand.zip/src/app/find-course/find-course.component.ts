import { Component, OnInit } from '@angular/core';
import { MentorSkills } from '../MentorSkills';
import { UserService } from '../user.service';

@Component({
  selector: 'app-find-course',
  templateUrl: './find-course.component.html',
  styleUrls: ['./find-course.component.css']
})
export class FindCourseComponent implements OnInit {
mentorSkills:MentorSkills[];
  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.MentorSkills()  
    .subscribe((data:MentorSkills[]) => { 
      console.log(data); 
      this.mentorSkills = data;  
    }); 
  }

}
