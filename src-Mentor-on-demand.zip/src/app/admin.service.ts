import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { PaymentHistory } from './PaymentHistory';
import { Payments } from './PaymentForm';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
 
  public baseUrl = 'http://localhost:8216/api';

  constructor(private http: HttpClient) { }
  createAdmin(admin: Object): Observable<Object> {
    console.log(admin);
    return this.http.post(`${this.baseUrl}`+'/adminDetails',admin);
  }
  savePaymentToMentor(payment: Object): Observable<Object> {
    console.log(payment);
    return this.http.post(`${this.baseUrl}`+'/payment',payment);
  }
  getPayment() {
    return this.http.get<PaymentHistory[]>(`${this.baseUrl}`+'/paymentHistoryList');
  }
  getPaymentHistoryId(selectedId:number): Observable<Object>{
    return this.http.get<PaymentHistory[]>(`${this.baseUrl}/paymentHistoryId/${selectedId}`);
  }
  addSkill(skill: Object): Observable<Object> {
    console.log(skill);
    return this.http.post(`${this.baseUrl}`+'/addSkill',skill);
  }
  getPaymentDetails() {
    return this.http.get<Payments[]>(`${this.baseUrl}`+'/paymentDetails');
  }
  getPaymentSlotWithId(selectedId:number): Observable<Object>{
    return this.http.get<Payments[]>(`${this.baseUrl}/paymentSlotWithId/${selectedId}`);
}
updateSlotPayment(payments: Object): Observable<Object> {
  console.log(payments);
  return this.http.post(`${this.baseUrl}`+'/updateSlot',payments);
}
}