import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  private user: Login[];
  login:Login=new Login();
  email:string;
  constructor(private loginService: LoginService) { }

  ngOnInit() {
    this.loginService._email$.subscribe(message=>this.email=message);
  }

}
