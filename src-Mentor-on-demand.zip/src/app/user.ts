

export class User {
    userId:number;
    userName:string;
    password:string;
    firstName:string;
    lastName:string;
    gender:string;
    email:string;
    contactNumber:string;
    regcode:string;
    activeStatus:string;
    address:string
}
