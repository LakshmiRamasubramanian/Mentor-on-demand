import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-mentor',
  templateUrl: './mentor.component.html',
  styleUrls: ['./mentor.component.css']
})
export class MentorComponent implements OnInit {

  constructor(private loginService: LoginService) { }
  private mentor: Login[];
  login:Login=new Login();
  email:string;
  ngOnInit() {
    this.loginService._email$.subscribe(message=>this.email=message);
  }

}
