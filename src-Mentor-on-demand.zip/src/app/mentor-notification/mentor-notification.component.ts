import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-notification',
  templateUrl: './mentor-notification.component.html',
  styleUrls: ['./mentor-notification.component.css']
})
export class MentorNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
