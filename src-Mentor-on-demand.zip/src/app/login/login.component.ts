import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Login } from '../login';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login:Login =new Login();
  email:string;

  private products : Login[];

  constructor(private router:Router,private loginService: LoginService) { }

  ngOnInit() {
    
  }
  
  loginCredentials(){
    console.log(this.login);
    
    this.loginService.getLoginCredentials(this.login)
    .subscribe((res : any[])=>{
      console.log(res);
      this.products = res;
      })
      this.checkLogin();
   
    
  }
  onSubmit() {

   
    this.loginCredentials();
   
  
  }
  checkLogin(){
  this.email=this.products[0].email;
  this.loginService.setEmail(this.email);
  if((this.products[0].role)=="admin"){
    this.router.navigate(['Admin']);
  }
  if((this.products[0].role)=="user"){
    this.router.navigate(['User']);
  }
  if((this.products[0].role)=="mentor"){
    this.router.navigate(['Mentor']);
  }
 
    }
  }

